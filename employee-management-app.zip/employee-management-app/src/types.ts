export interface Employee {
  id: string;
  name: string;
  email: string;
  mobile: string;
  country: string;
  state: string;
  district: string;
}

export interface Country {
  id: string;
  name: string;
  states?: string[];
}

export interface EmployeeFormValues {
  name: string;
  email: string;
  mobile: string;
  country: string;
  state: string;
  district: string;
}
