import { AppBar, Toolbar, Typography, Box } from "@mui/material";
import GroupsIcon from "@mui/icons-material/Groups";

export default function AppHeader() {
  return (
    <AppBar position="static" elevation={0}>
      <Toolbar>
        <GroupsIcon sx={{ mr: 1 }} />
        <Typography variant="h6" fontWeight={700}>Employee Management</Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Typography variant="body2">React + Redux Toolkit</Typography>
      </Toolbar>
    </AppBar>
  );
}
