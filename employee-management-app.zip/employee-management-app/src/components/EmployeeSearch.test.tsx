import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import EmployeeSearch from "./EmployeeSearch";

describe("EmployeeSearch", () => {
  it("submits the entered employee id", async () => {
    const user = userEvent.setup();
    const onSearch = vi.fn();
    render(<EmployeeSearch onSearch={onSearch} onReset={vi.fn()} />);
    await user.type(screen.getByLabelText(/search employee by id/i), "123");
    await user.click(screen.getByRole("button", { name: /search/i }));
    expect(onSearch).toHaveBeenCalledWith("123");
  });
});
