import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import EmployeeForm from "./EmployeeForm";

describe("EmployeeForm", () => {
  it("shows validation messages for empty submission", async () => {
    const user = userEvent.setup();
    render(
      <EmployeeForm
        open
        employee={null}
        countries={[{ id: "1", name: "India" }]}
        saving={false}
        onClose={vi.fn()}
        onSubmit={vi.fn()}
      />
    );
    await user.click(screen.getByRole("button", { name: /create/i }));
    expect(screen.getAllByText("This field is required.")).toHaveLength(6);
  });

  it("pre-populates edit data", () => {
    render(
      <EmployeeForm
        open
        employee={{
          id: "1", name: "Test User", email: "test@example.com",
          mobile: "9876543210", country: "India", state: "Maharashtra", district: "Pune"
        }}
        countries={[{ id: "1", name: "India" }]}
        saving={false}
        onClose={vi.fn()}
        onSubmit={vi.fn()}
      />
    );
    expect(screen.getByDisplayValue("Test User")).toBeInTheDocument();
    expect(screen.getByDisplayValue("test@example.com")).toBeInTheDocument();
  });
});
