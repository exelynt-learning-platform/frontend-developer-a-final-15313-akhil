import { Alert, Box, CircularProgress, Typography } from "@mui/material";

export function LoadingView() {
  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight={220} gap={2}>
      <CircularProgress size={30} />
      <Typography color="text.secondary">Loading...</Typography>
    </Box>
  );
}

export function ErrorView({ message }: { message: string }) {
  return <Alert severity="error" sx={{ my: 2 }}>{message}</Alert>;
}

export function EmptyView({ message }: { message: string }) {
  return (
    <Box textAlign="center" py={8}>
      <Typography color="text.secondary">{message}</Typography>
    </Box>
  );
}
