import { useEffect, useState } from "react";
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle,
  Grid, MenuItem, TextField
} from "@mui/material";
import type { Country, Employee, EmployeeFormValues } from "../types";
import { validateEmployee, type FormErrors } from "../validation";

const emptyForm: EmployeeFormValues = {
  name: "", email: "", mobile: "", country: "", state: "", district: ""
};

interface Props {
  open: boolean;
  employee: Employee | null;
  countries: Country[];
  saving: boolean;
  onClose: () => void;
  onSubmit: (values: EmployeeFormValues) => Promise<void>;
}

export default function EmployeeForm({ open, employee, countries, saving, onClose, onSubmit }: Props) {
  const [values, setValues] = useState<EmployeeFormValues>(emptyForm);
  const [errors, setErrors] = useState<FormErrors>({});

  useEffect(() => {
    setValues(employee ? {
      name: employee.name, email: employee.email, mobile: employee.mobile,
      country: employee.country, state: employee.state, district: employee.district
    } : emptyForm);
    setErrors({});
  }, [employee, open]);

  const update = (field: keyof EmployeeFormValues, value: string) => {
    setValues(v => ({ ...v, [field]: value }));
    setErrors(e => ({ ...e, [field]: undefined }));
  };

  const submit = async () => {
    const nextErrors = validateEmployee(values);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    await onSubmit(values);
  };

  return (
    <Dialog open={open} onClose={saving ? undefined : onClose} fullWidth maxWidth="sm">
      <DialogTitle>{employee ? "Edit Employee" : "Add Employee"}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2} sx={{ pt: 0.5 }}>
          {([
            ["name", "Name"],
            ["email", "Email"],
            ["mobile", "Mobile"],
            ["state", "State"],
            ["district", "District"]
          ] as const).map(([field, label]) => (
            <Grid key={field} size={{ xs: 12, sm: field === "name" || field === "email" ? 6 : 12 }}>
              <TextField
                fullWidth
                label={label}
                value={values[field]}
                onChange={e => update(field, e.target.value)}
                error={Boolean(errors[field])}
                helperText={errors[field]}
                inputProps={{ maxLength: field === "name" ? 80 : field === "email" ? 120 : 80 }}
              />
            </Grid>
          ))}
          <Grid size={{ xs: 12, sm: 6 }}>
            <TextField
              select fullWidth label="Country" value={values.country}
              onChange={e => update("country", e.target.value)}
              error={Boolean(errors.country)} helperText={errors.country}
            >
              {countries.map(country => (
                <MenuItem value={country.name} key={country.id}>{country.name}</MenuItem>
              ))}
            </TextField>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 2 }}>
        <Button onClick={onClose} disabled={saving}>Cancel</Button>
        <Button variant="contained" onClick={submit} disabled={saving}>
          {saving ? "Saving..." : employee ? "Update" : "Create"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
