import { useState } from "react";
import { Button, Stack, TextField } from "@mui/material";

interface Props {
  onSearch: (id: string) => void;
  onReset: () => void;
}

export default function EmployeeSearch({ onSearch, onReset }: Props) {
  const [id, setId] = useState("");

  return (
    <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5}>
      <TextField
        size="small"
        label="Search employee by ID"
        value={id}
        onChange={e => setId(e.target.value)}
        onKeyDown={e => e.key === "Enter" && onSearch(id.trim())}
      />
      <Button variant="outlined" onClick={() => onSearch(id.trim())}>Search</Button>
      <Button onClick={() => { setId(""); onReset(); }}>Show All</Button>
    </Stack>
  );
}
