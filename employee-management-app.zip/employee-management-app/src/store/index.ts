import { configureStore, createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import type { Country, Employee, EmployeeFormValues } from "../types";
import { employeeApi } from "../api/employeeApi";
import { countryApi } from "../api/countryApi";

type AsyncState = { loading: boolean; error: string | null };

interface EmployeesState extends AsyncState {
  items: Employee[];
  selected: Employee | null;
}

interface CountriesState extends AsyncState {
  items: Country[];
}

const initialEmployees: EmployeesState = {
  items: [],
  selected: null,
  loading: false,
  error: null
};

const initialCountries: CountriesState = {
  items: [],
  loading: false,
  error: null
};

const errorMessage = (e: unknown) =>
  e instanceof Error ? e.message : "Something went wrong. Please try again.";

export const fetchEmployees = createAsyncThunk("employees/fetchAll", employeeApi.getAll);
export const fetchEmployeeById = createAsyncThunk("employees/fetchById", employeeApi.getById);
export const createEmployee = createAsyncThunk(
  "employees/create",
  (data: EmployeeFormValues) => employeeApi.create(data)
);
export const updateEmployee = createAsyncThunk(
  "employees/update",
  ({ id, data }: { id: string; data: EmployeeFormValues }) => employeeApi.update(id, data)
);
export const deleteEmployee = createAsyncThunk("employees/delete", employeeApi.remove);
export const fetchCountries = createAsyncThunk("countries/fetchAll", countryApi.getAll);

const employeesSlice = createSlice({
  name: "employees",
  initialState: initialEmployees,
  reducers: {
    clearSelected: state => { state.selected = null; },
    setSelected: (state, action: PayloadAction<Employee | null>) => {
      state.selected = action.payload;
    }
  },
  extraReducers: builder => {
    builder
      .addCase(fetchEmployees.pending, state => {
        state.loading = true; state.error = null;
      })
      .addCase(fetchEmployees.fulfilled, (state, action) => {
        state.loading = false; state.items = action.payload;
      })
      .addCase(fetchEmployees.rejected, (state, action) => {
        state.loading = false; state.error = action.error.message ?? "Unable to load employees.";
      })
      .addCase(fetchEmployeeById.pending, state => {
        state.loading = true; state.error = null; state.selected = null;
      })
      .addCase(fetchEmployeeById.fulfilled, (state, action) => {
        state.loading = false; state.selected = action.payload;
      })
      .addCase(fetchEmployeeById.rejected, (state, action) => {
        state.loading = false; state.error = action.error.message ?? "Employee not found.";
      })
      .addCase(createEmployee.pending, state => {
        state.loading = true; state.error = null;
      })
      .addCase(createEmployee.fulfilled, (state, action) => {
        state.loading = false; state.items.unshift(action.payload);
      })
      .addCase(createEmployee.rejected, (state, action) => {
        state.loading = false; state.error = action.error.message ?? "Unable to create employee.";
      })
      .addCase(updateEmployee.pending, state => {
        state.loading = true; state.error = null;
      })
      .addCase(updateEmployee.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.items.findIndex(e => e.id === action.payload.id);
        if (index >= 0) state.items[index] = action.payload;
        state.selected = action.payload;
      })
      .addCase(updateEmployee.rejected, (state, action) => {
        state.loading = false; state.error = action.error.message ?? "Unable to update employee.";
      })
      .addCase(deleteEmployee.pending, state => {
        state.loading = true; state.error = null;
      })
      .addCase(deleteEmployee.fulfilled, (state, action) => {
        state.loading = false;
        state.items = state.items.filter(e => e.id !== action.payload);
      })
      .addCase(deleteEmployee.rejected, (state, action) => {
        state.loading = false; state.error = action.error.message ?? "Unable to delete employee.";
      });
  }
});

const countriesSlice = createSlice({
  name: "countries",
  initialState: initialCountries,
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(fetchCountries.pending, state => {
        state.loading = true; state.error = null;
      })
      .addCase(fetchCountries.fulfilled, (state, action) => {
        state.loading = false; state.items = action.payload;
      })
      .addCase(fetchCountries.rejected, (state, action) => {
        state.loading = false; state.error = action.error.message ?? "Unable to load countries.";
      });
  }
});

export const { clearSelected, setSelected } = employeesSlice.actions;

export const store = configureStore({
  reducer: {
    employees: employeesSlice.reducer,
    countries: countriesSlice.reducer
  }
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
