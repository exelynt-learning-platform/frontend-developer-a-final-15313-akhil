import { describe, expect, it, vi } from "vitest";
import { employeeApi } from "../api/employeeApi";
import { createEmployee, deleteEmployee, store } from "./index";

const employee = {
  id: "1", name: "Akhil", email: "akhil@example.com", mobile: "9876543210",
  country: "India", state: "Maharashtra", district: "Pune"
};

describe("Redux employee state", () => {
  it("updates state after a successful create thunk", async () => {
    vi.spyOn(employeeApi, "create").mockResolvedValue(employee);
    await store.dispatch(createEmployee(employee));
    expect(store.getState().employees.items.some(e => e.id === "1")).toBe(true);
    vi.restoreAllMocks();
  });

  it("updates state after a successful delete thunk", async () => {
    vi.spyOn(employeeApi, "remove").mockResolvedValue("1");
    await store.dispatch(deleteEmployee("1"));
    expect(store.getState().employees.items.some(e => e.id === "1")).toBe(false);
    vi.restoreAllMocks();
  });
});
