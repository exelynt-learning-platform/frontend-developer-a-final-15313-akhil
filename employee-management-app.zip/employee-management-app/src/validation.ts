import type { EmployeeFormValues } from "./types";

export type FormErrors = Partial<Record<keyof EmployeeFormValues, string>>;

export function validateEmployee(values: EmployeeFormValues): FormErrors {
  const errors: FormErrors = {};
  const required = ["name", "email", "mobile", "country", "state", "district"] as const;

  required.forEach(field => {
    if (!values[field].trim()) errors[field] = "This field is required.";
  });

  if (values.name && (values.name.trim().length < 2 || values.name.trim().length > 80)) {
    errors.name = "Name must be between 2 and 80 characters.";
  }
  if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.email = "Enter a valid email address.";
  }
  if (values.email && values.email.length > 120) errors.email = "Email cannot exceed 120 characters.";
  if (values.mobile && !/^[0-9+() -]{7,20}$/.test(values.mobile)) {
    errors.mobile = "Enter a valid mobile number.";
  }
  if (values.state && values.state.trim().length > 80) errors.state = "State cannot exceed 80 characters.";
  if (values.district && values.district.trim().length > 80) errors.district = "District cannot exceed 80 characters.";

  return errors;
}
