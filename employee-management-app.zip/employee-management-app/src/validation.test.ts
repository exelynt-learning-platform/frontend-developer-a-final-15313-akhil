import { describe, expect, it } from "vitest";
import { validateEmployee } from "./validation";

const valid = {
  name: "Akhil Rale",
  email: "akhil@example.com",
  mobile: "9876543210",
  country: "India",
  state: "Maharashtra",
  district: "Pune"
};

describe("validateEmployee", () => {
  it("accepts valid employee data", () => {
    expect(validateEmployee(valid)).toEqual({});
  });

  it("requires all fields", () => {
    const errors = validateEmployee({
      name: "", email: "", mobile: "", country: "", state: "", district: ""
    });
    expect(Object.keys(errors)).toHaveLength(6);
  });

  it("validates email format", () => {
    expect(validateEmployee({ ...valid, email: "bad-email" }).email).toBeTruthy();
  });

  it("validates name length", () => {
    expect(validateEmployee({ ...valid, name: "A" }).name).toContain("2 and 80");
  });
});
