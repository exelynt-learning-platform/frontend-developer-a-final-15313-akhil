import { describe, expect, it, vi } from "vitest";
import { employeeApi } from "./employeeApi";
import { api } from "./http";

describe("employeeApi", () => {
  it("calls GET /employee", async () => {
    const spy = vi.spyOn(api, "get").mockResolvedValue({ data: [] } as never);
    await employeeApi.getAll();
    expect(spy).toHaveBeenCalledWith("/employee");
    spy.mockRestore();
  });

  it("calls DELETE with the employee id", async () => {
    const spy = vi.spyOn(api, "delete").mockResolvedValue({} as never);
    await employeeApi.remove("42");
    expect(spy).toHaveBeenCalledWith("/employee/42");
    spy.mockRestore();
  });
});
