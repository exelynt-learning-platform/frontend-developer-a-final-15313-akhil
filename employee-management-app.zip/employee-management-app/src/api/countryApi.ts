import { api } from "./http";
import type { Country } from "../types";

export const countryApi = {
  getAll: () => api.get<Country[]>("/country").then(r => r.data)
};
