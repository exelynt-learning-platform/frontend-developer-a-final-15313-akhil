import { api } from "./http";
import type { Employee, EmployeeFormValues } from "../types";

export const employeeApi = {
  getAll: () => api.get<Employee[]>("/employee").then(r => r.data),
  getById: (id: string) => api.get<Employee>(`/employee/${id}`).then(r => r.data),
  create: (data: EmployeeFormValues) =>
    api.post<Employee>("/employee", data).then(r => r.data),
  update: (id: string, data: EmployeeFormValues) =>
    api.put<Employee>(`/employee/${id}`, data).then(r => r.data),
  remove: (id: string) => api.delete(`/employee/${id}`).then(() => id)
};
