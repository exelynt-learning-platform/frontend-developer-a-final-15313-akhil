import { useEffect } from "react";
import { Box, Container } from "@mui/material";
import AppHeader from "./components/AppHeader";
import EmployeePage from "./pages/EmployeePage";
import { useAppDispatch } from "./store/hooks";
import { fetchCountries, fetchEmployees } from "./store";

export default function App() {
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(fetchEmployees());
    dispatch(fetchCountries());
  }, [dispatch]);

  return (
    <Box minHeight="100vh">
      <AppHeader />
      <Container maxWidth="xl" sx={{ py: { xs: 2, md: 4 } }}>
        <EmployeePage />
      </Container>
    </Box>
  );
}
