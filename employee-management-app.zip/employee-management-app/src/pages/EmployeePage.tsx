import { useMemo, useState } from "react";
import {
  Alert, Box, Button, Card, CardContent, Dialog, DialogActions, DialogTitle,
  Divider, Stack, Typography
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import RefreshIcon from "@mui/icons-material/Refresh";
import EmployeeForm from "../components/EmployeeForm";
import EmployeeSearch from "../components/EmployeeSearch";
import EmployeeTable from "../components/EmployeeTable";
import { EmptyView, ErrorView, LoadingView } from "../components/StatusView";
import type { Employee, EmployeeFormValues } from "../types";
import { useAppDispatch, useAppSelector } from "../store/hooks";
import {
  createEmployee, deleteEmployee, fetchEmployeeById, fetchEmployees,
  setSelected, updateEmployee
} from "../store";

export default function EmployeePage() {
  const dispatch = useAppDispatch();
  const { items, loading, error, selected } = useAppSelector(s => s.employees);
  const countries = useAppSelector(s => s.countries.items);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Employee | null>(null);
  const [searchMessage, setSearchMessage] = useState("");
  const [searching, setSearching] = useState(false);

  const displayEmployees = useMemo(() => {
    if (selected) return [selected];
    return items;
  }, [selected, items]);

  const openCreate = () => { setEditing(null); setFormOpen(true); };
  const openEdit = (employee: Employee) => { setEditing(employee); setFormOpen(true); };

  const save = async (values: EmployeeFormValues) => {
    try {
      if (editing) await dispatch(updateEmployee({ id: editing.id, data: values })).unwrap();
      else await dispatch(createEmployee(values)).unwrap();
      setFormOpen(false);
      setEditing(null);
      setSearchMessage("");
    } catch {
      // Redux state exposes the API error.
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await dispatch(deleteEmployee(deleteTarget.id)).unwrap();
      setDeleteTarget(null);
      dispatch(setSelected(null));
      setSearchMessage("");
    } catch {
      // Redux state exposes the API error.
    }
  };

  const searchById = async (id: string) => {
    if (!id) { setSearchMessage("Please enter an employee ID."); return; }
    setSearching(true);
    setSearchMessage("");
    dispatch(setSelected(null));
    try {
      await dispatch(fetchEmployeeById(id)).unwrap();
    } catch {
      setSearchMessage(`No employee found with ID "${id}".`);
    } finally {
      setSearching(false);
    }
  };

  const refresh = () => {
    dispatch(setSelected(null));
    setSearchMessage("");
    dispatch(fetchEmployees());
  };

  return (
    <>
      <Stack spacing={3}>
        <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" gap={2}>
          <Box>
            <Typography variant="h4" fontWeight={800}>Employees</Typography>
            <Typography color="text.secondary">Manage employee records from one responsive dashboard.</Typography>
          </Box>
          <Stack direction="row" spacing={1}>
            <Button startIcon={<RefreshIcon />} onClick={refresh}>Refresh</Button>
            <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>Add Employee</Button>
          </Stack>
        </Stack>

        <Card>
          <CardContent>
            <Stack spacing={2}>
              <EmployeeSearch onSearch={searchById} onReset={() => dispatch(setSelected(null))} />
              {searchMessage && <Alert severity="info">{searchMessage}</Alert>}
            </Stack>
          </CardContent>
        </Card>

        {error && <ErrorView message={error} />}

        {loading || searching ? <LoadingView /> :
          displayEmployees.length ? (
            <EmployeeTable employees={displayEmployees} onEdit={openEdit} onDelete={setDeleteTarget} />
          ) : (
            <Card><CardContent><EmptyView message="No employees available." /></CardContent></Card>
          )
        }

        <Card>
          <CardContent>
            <Typography variant="body2" color="text.secondary">
              {items.length} employee record{items.length === 1 ? "" : "s"} loaded.
            </Typography>
          </CardContent>
        </Card>
      </Stack>

      <EmployeeForm
        open={formOpen}
        employee={editing}
        countries={countries}
        saving={loading}
        onClose={() => setFormOpen(false)}
        onSubmit={save}
      />

      <Dialog open={Boolean(deleteTarget)} onClose={() => setDeleteTarget(null)}>
        <DialogTitle>Delete employee?</DialogTitle>
        <CardContent>
          <Typography>
            Are you sure you want to delete <b>{deleteTarget?.name}</b>? This action cannot be undone.
          </Typography>
        </CardContent>
        <Divider />
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={confirmDelete} disabled={loading}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
