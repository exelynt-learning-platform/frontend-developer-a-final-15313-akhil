# Employee Management Application

A responsive React + TypeScript employee management application demonstrating:

- React component architecture with Smart/Dumb separation
- Redux Toolkit for employee/country state management
- Axios API integration with the supplied MockAPI endpoints
- Material UI responsive design
- Create, read, update and delete employee operations
- Employee ID search with a clear not-found message
- Delete confirmation
- Pre-populated edit form
- Form validation for required fields, email format and field lengths
- Loading, error and empty states
- Unit tests for validation, components and API service behavior

## Architecture

```text
src/
  api/
    http.ts
    employeeApi.ts
    countryApi.ts
  components/
    AppHeader.tsx
    EmployeeTable.tsx
    EmployeeSearch.tsx
    EmployeeForm.tsx
    StatusView.tsx
  pages/
    EmployeePage.tsx       # Smart component: state + business logic
  store/
    index.ts               # Redux Toolkit slices + async thunks
    hooks.ts
  types.ts
  validation.ts
  App.tsx
  main.tsx
```

### Smart / Dumb components

`EmployeePage` is the smart/container component. It reads Redux state, dispatches async operations, controls dialogs and passes callbacks/data to presentational components.

`EmployeeTable`, `EmployeeSearch`, `EmployeeForm`, `StatusView`, and `AppHeader` are dumb/presentational components. They receive data/callbacks and focus on rendering and user interaction.

## API

Base URL:

`https://669b3f09276e45187d34eb4e.mockapi.io/api/v1`

Endpoints:

- `GET /country`
- `GET /employee`
- `GET /employee/:id`
- `POST /employee`
- `PUT /employee/:id`
- `DELETE /employee/:id`

## Run locally

Requirements: Node.js 18+ recommended.

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Test

```bash
npm test
```

## Production build

```bash
npm run build
```

## Notes

The country API response is treated generically as `{ id, name }`. If the MockAPI dataset contains nested state/district data, the form can be extended to populate dependent State and District selects without changing the overall architecture.

For a production application, add authentication, centralized API error normalization, pagination, server-side search, accessibility auditing, and environment variables for the API base URL.
